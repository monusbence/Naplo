﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string naplo = "naplo.csv";
        List<OsztalyzatokBetoltese> jegyek = new List<OsztalyzatokBetoltese>();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            
            using StreamWriter writer = new StreamWriter(naplo, append: true);
            {
                writer.WriteLine($"{txtNev.Text};{cboTantárgy.Text};{dpDatum.Text};{sliCsuszka.Value}");
                writer.Close();
            }
        }

        private void sliCsuszka_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            lblÉrték.Content = Math.Round(sliCsuszka.Value);
        }

        private void btnBetölt_Click(object sender, RoutedEventArgs e)
        {
            StreamReader sr = new StreamReader("naplo.csv", encoding: Encoding.UTF8);
            while (!sr.EndOfStream)
            {
                string[] sor = sr.ReadLine().Split(";");
                OsztalyzatokBetoltese ujJegy = new OsztalyzatokBetoltese(sor[0], sor[1], sor[2], int.Parse(sor[3]));
                jegyek.Add(ujJegy);
            }
            sr.Close();
            dgJegyek.ItemsSource = jegyek;
        }

    }
}
